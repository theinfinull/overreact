import { createElement, render } from './overreact.js';

const container = document.getElementById('root');
const element = (
  <div id="hero">
    <img src="hero.png"></img>
    <h1>It's Working!</h1>
    <p>
      Seems our <code>render</code> is working in tiny pieces now, finally
      letting the browser breathe.
    </p>
  </div>
);

render(element, container);
