import { defineConfig } from "vite";

export default defineConfig({
    esbuild: {
        // compile JSX into createElement(...) calls
        jsxFactory: "createElement",
    },
});
