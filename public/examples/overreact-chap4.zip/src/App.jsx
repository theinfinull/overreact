import { createElement } from './overreact.js';
import { ToastDemo } from './components/ToastDemo.jsx';

const steps = [
  { title: 'Parsing And Rendering', done: true },
  { title: 'Rendering In Pieces', done: true },
  { title: 'Reconciliation', done: true },
  { title: 'Functional Components', done: true },
  { title: 'Hooks' },
];

const content = (
  <p className="hero-content">
    Break the UI into small functions. Reuse them anywhere. <code>Toast</code>{' '}
    is just the start.
  </p>
);

export default function App() {
  return (
    <div id="hero">
      <div className="hero-badge">
        <b>Status</b>
        <em>200 OK</em>
      </div>
      <img className="hero-img" src="hero.jpg"></img>
      <h1 className="hero-heading">It's Working!</h1>
      {content}
      <ul className="hero-steps-container">
        {steps.map((step, index) => (
          <li
            key={index}
            className={step.done ? 'hero-step done' : 'hero-step'}
          >
            <span className="hero-step-dot"></span>
            <span className="hero-step-title">{step.title}</span>
          </li>
        ))}
      </ul>
      <div className="fn-card">
        <div className="fn-head">
          <h3 className="fn-title">Functional Components</h3>
        </div>
        <p className="fn-desc">
          One <code>Toast</code> function, three different props. Click one to
          see its code.
        </p>
        <ToastDemo />
      </div>
    </div>
  );
}
