import App from './App.jsx';
import { createElement, render } from './overreact.js';

const container = document.getElementById('root');

export const update = () => render(<App />, container);

update();
