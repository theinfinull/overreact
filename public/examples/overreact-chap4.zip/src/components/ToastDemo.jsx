import { createElement } from '../overreact.js';
// circular import, but safe: `update` is only called on click, after every module has loaded
import { update } from '../main.jsx';

const icons = { success: '✓', error: '✕', info: 'i' };

const toasts = [
  { id: 'success', type: 'success', text: 'Changes saved' },
  { id: 'error', type: 'error', text: 'Upload failed' },
  { id: 'info', type: 'info', text: 'New version available' },
];

const usage = (t) => `<Toast type="${t.type}">
  ${t.text}
</Toast>`;

const toastSource = `const Toast = ({ type, children }) => (
  <div className={\`toast toast--\${type}\`}>
    <span>{icons[type]}</span>
    {children}
  </div>
);`;

/* tiny jsx highlighter: split source into tokens, wrap each in a span */
const tokenRe =
  /(`[^`]*`|"[^"]*"|'[^']*')|(<\/?[A-Za-z]\w*|\/?>)|\b(const|return|function)\b|([A-Za-z]+)(?==)|(=>|[{}()[\]])|(?<=const )([A-Z]\w*)/g;
const tokenTypes = ['str', 'tag', 'kw', 'attr', 'punc', 'comp'];

const highlight = (code) => {
  const out = [];
  let last = 0;
  for (const m of code.matchAll(tokenRe)) {
    if (m.index > last) out.push(code.slice(last, m.index));
    const i = m.slice(1).findIndex((g) => g !== undefined);
    out.push(<span className={`tok-${tokenTypes[i]}`}>{m[0]}</span>);
    last = m.index + m[0].length;
  }
  out.push(code.slice(last));
  return out;
};

/* no hooks yet: plain variable + re-render */
let selected = null;

const select = (id) => {
  selected = selected === id ? null : id;
  update();
};

function Toast({ type, active, onClick, children }) {
  return (
    <div
      className={
        active ? `toast toast--${type} is-active` : `toast toast--${type}`
      }
      onClick={onClick}
    >
      <span className="toast-icon">{icons[type]}</span>
      <span className="toast-text">{children}</span>
    </div>
  );
}

export function ToastDemo() {
  const current = toasts.find((t) => t.id === selected);

  return (
    <div className="toast-demo">
      <div className="toast-list">
        {toasts.map((t) => (
          <Toast
            type={t.type}
            active={selected === t.id}
            onClick={() => select(t.id)}
          >
            {t.text}
          </Toast>
        ))}
      </div>
      {current ? (
        <div className="toast-code">
          <div className="toast-code-label">usage</div>
          <pre>{highlight(usage(current))}</pre>
          <div className="toast-code-label">component</div>
          <pre>{highlight(toastSource)}</pre>
        </div>
      ) : (
        <p className="toast-hint">↑ tap a toast</p>
      )}
    </div>
  );
}
