import { createElement, useState } from '../overreact.js';

export default function Counter() {
  const [count, setCount] = useState(0);

  return (
    <div className="counter">
      <span className="counter-value">{count}</span>
      <div className="counter-actions">
        <button className="counter-btn" onClick={() => setCount((c) => c - 1)}>
          −
        </button>
        <button className="counter-btn" onClick={() => setCount(0)}>
          Reset
        </button>
        <button className="counter-btn" onClick={() => setCount((c) => c + 1)}>
          +
        </button>
      </div>
    </div>
  );
}
