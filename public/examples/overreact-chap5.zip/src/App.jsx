import { createElement } from './overreact.js';
import Counter from './components/Counter.jsx';

const steps = [
  { title: 'Parsing And Rendering', done: true },
  { title: 'Rendering In Pieces', done: true },
  { title: 'Reconciliation', done: true },
  { title: 'Functional Components', done: true },
  { title: 'State', done: true },
];

const content = (
  <p className="hero-content">
    Components can remember things now. Call <code>useState</code>, update it,
    and the UI re-renders on its own.
  </p>
);

export default function App() {
  return (
    <div id="hero">
      <div className="hero-badge">
        <b>Status</b>
        <em>200 OK</em>
      </div>
      <img className="hero-img" src="hero.jpg"></img>
      <h1 className="hero-heading">It's Working!</h1>
      {content}
      <ul className="hero-steps-container">
        {steps.map((step, index) => (
          <li
            key={index}
            className={step.done ? 'hero-step done' : 'hero-step'}
          >
            <span className="hero-step-dot"></span>
            <span className="hero-step-title">{step.title}</span>
          </li>
        ))}
      </ul>
      <div className="fn-card">
        <h3 className="fn-title">State</h3>
        <p className="fn-desc">
          <code>useState(0)</code> keeps the count between renders. Click to
          update it.
        </p>
        <Counter />
      </div>
    </div>
  );
}
