import App from './App.jsx';
import { createElement, render } from './overreact.js';

render(<App />, document.getElementById('root'));
