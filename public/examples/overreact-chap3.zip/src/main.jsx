import { createElement, render } from './overreact.js';

const steps = [
  { title: 'Parsing And Rendering', done: true },
  { title: 'Rendering In Pieces', done: true },
  { title: 'Reconciliation', done: true },
  { title: 'Functional Components' },
  { title: 'Hooks' },
];

const content = (
  <p className="hero-content">
    The DOM used to get redrawn for everything. Now it gets a tap on the
    shoulder.
  </p>
);

/* keyed chips state (no hooks yet, so plain variables + re-render) */
let chips = [1, 2, 3];
let nextChipId = 4;

const addChip = () => {
  chips = [...chips, nextChipId++];
  update();
};

const removeChip = (id) => {
  chips = chips.filter((chip) => chip !== id);
  update();
};

const container = document.getElementById('root');
const view = () => (
  <div id="hero">
    <div className="hero-badge">
      <b>Status</b>
      <em>200 OK</em>
    </div>
    <img className="hero-img" src="hero.jpg"></img>
    <h1 className="hero-heading">It's Working!</h1>
    {content}
    <ul className="hero-steps-container">
      {steps.map((step, index) => (
        <li key={index} className={step.done ? 'hero-step done' : 'hero-step'}>
          <span className="hero-step-dot"></span>
          <span className="hero-step-title">{step.title}</span>
        </li>
      ))}
    </ul>
    <div className="recon-card">
      <div className="recon-head">
        <h3 className="recon-title">Reconciliation Demo</h3>
        <button className="recon-add" onClick={addChip}>
          +
        </button>
      </div>
      <p className="recon-desc">
        Each click calls <code>render()</code> again with a new tree. Only the
        box you add or remove touches the DOM, the rest are diffed and kept. New
        boxes flash purple so you can see it.
      </p>
      <div className="recon-chips">
        {chips.map((id) => (
          <div key={id} className="recon-chip">
            <span className="recon-chip-label">div {id}</span>
            <button
              className="recon-chip-remove"
              onClick={() => removeChip(id)}
            >
              ×
            </button>
          </div>
        ))}
      </div>
    </div>
  </div>
);

const update = () => render(view(), container);

update();
