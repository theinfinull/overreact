import { createElement, render } from './overreact.js';

const steps = [
  { title: 'Parsing And Rendering', done: true },
  { title: 'Rendering In Pieces', done: true },
  { title: 'Reconciliation' },
  { title: 'Functional Components' },
  { title: 'Hooks' },
];

const content = (
  <p className="hero-content">
    Our <code>render</code> now breaks work into smaller pieces, letting the
    browser breathe.
  </p>
);

const container = document.getElementById('root');
const element = (
  <div id="hero">
    <div className="hero-badge">
      <b>Status</b>
      <em>200 OK</em>
    </div>
    <img className="hero-img" src="hero.jpg"></img>
    <h1 className="hero-heading">It's Working!</h1>
    {content}
    <ul className="hero-steps-container">
      {steps.map((step, index) => (
        <li className={step.done ? 'hero-step done' : 'hero-step'}>
          <span className="hero-step-dot"></span>
          <span className="hero-step-title">{step.title}</span>
        </li>
      ))}
    </ul>
  </div>
);

render(element, container);
